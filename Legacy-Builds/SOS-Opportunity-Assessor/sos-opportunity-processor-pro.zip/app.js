// SOS Opportunity Checklist Processor - Enhanced Version
class SOSProcessor {
    constructor() {
        this.opportunities = [];
        this.currentSelectedIndex = -1;
        this.charts = {};
        this.filteredOpportunities = [];
        this.init();
    }

    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.setupEventListeners();
                this.setupKeyboardShortcuts();
                this.loadFromStorage();
                this.updateStats();
                this.renderDashboard();
                this.renderHistory();
            });
        } else {
            this.setupEventListeners();
            this.setupKeyboardShortcuts();
            this.loadFromStorage();
            this.updateStats();
            this.renderDashboard();
            this.renderHistory();
        }
    }

    // Event Listeners Setup
    setupEventListeners() {
        // Tab navigation - Fixed
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const tabName = e.currentTarget.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });

        // Process button
        const processBtn = document.getElementById('processBtn');
        if (processBtn) {
            processBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.processOpportunities();
            });
        }

        // Clear button
        const clearBtn = document.getElementById('clearBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.clearAll();
            });
        }

        // Search and filters - Fixed
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filterOpportunities();
            });
        }

        const statusFilter = document.getElementById('statusFilter');
        if (statusFilter) {
            statusFilter.addEventListener('change', (e) => {
                this.filterOpportunities();
            });
        }

        const naicsFilter = document.getElementById('naicsFilter');
        if (naicsFilter) {
            naicsFilter.addEventListener('change', (e) => {
                this.filterOpportunities();
            });
        }

        // Export functionality - Fixed
        const exportBtn = document.getElementById('exportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleExportMenu();
            });
        }

        // Close export menu when clicking outside
        document.addEventListener('click', (e) => {
            const exportMenu = document.getElementById('exportMenu');
            const exportBtn = document.getElementById('exportBtn');
            if (exportMenu && !exportBtn.contains(e.target) && !exportMenu.contains(e.target)) {
                exportMenu.classList.remove('show');
            }
        });

        document.querySelectorAll('[data-format]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.exportData(e.target.getAttribute('data-format'));
            });
        });

        // Modal controls - Fixed
        const modalClose = document.getElementById('modalClose');
        if (modalClose) {
            modalClose.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeModal('detailModal');
            });
        }

        const helpBtn = document.getElementById('helpBtn');
        if (helpBtn) {
            helpBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showModal('helpModal');
            });
        }

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleTheme();
            });
        }

        // PDF upload
        const pdfInput = document.getElementById('pdfInput');
        if (pdfInput) {
            pdfInput.addEventListener('change', (e) => {
                this.handlePDFUpload(e.target.files);
            });
        }

        // History clear
        const clearHistoryBtn = document.getElementById('clearHistoryBtn');
        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.clearHistory();
            });
        }

        // Close modal on outside click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });

        // Close help modal
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.closeModal(modal.id);
                }
            });
        });
    }

    // Keyboard Shortcuts - Fixed
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch(e.code) {
                    case 'KeyV':
                        if (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
                            e.preventDefault();
                            this.focusFirstEmptyTextarea();
                        }
                        break;
                    case 'Enter':
                        e.preventDefault();
                        this.processOpportunities();
                        break;
                    case 'KeyS':
                        e.preventDefault();
                        this.saveResults();
                        break;
                    case 'KeyE':
                        e.preventDefault();
                        this.toggleExportMenu();
                        break;
                    case 'KeyF':
                        e.preventDefault();
                        const searchInput = document.getElementById('searchInput');
                        if (searchInput) searchInput.focus();
                        break;
                    case 'KeyH':
                        e.preventDefault();
                        this.showModal('helpModal');
                        break;
                }
            } else {
                switch(e.code) {
                    case 'Escape':
                        this.closeAllModals();
                        break;
                    case 'ArrowUp':
                        if (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
                            e.preventDefault();
                            this.navigateOpportunities(-1);
                        }
                        break;
                    case 'ArrowDown':
                        if (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
                            e.preventDefault();
                            this.navigateOpportunities(1);
                        }
                        break;
                    case 'Space':
                        if (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
                            e.preventDefault();
                            this.toggleOpportunityDetails();
                        }
                        break;
                }
            }
        });
    }

    // Tab Management - Fixed
    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        const activeTab = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        const activeContent = document.getElementById(`${tabName}Tab`);
        if (activeContent) {
            activeContent.classList.add('active');
        }

        // Load analytics if switching to analytics tab
        if (tabName === 'analytics') {
            setTimeout(() => this.renderAnalytics(), 100);
        }
    }

    // Opportunity Processing
    async processOpportunities() {
        this.showLoading();
        
        const textareas = document.querySelectorAll('.copy-box textarea');
        const inputs = Array.from(textareas)
            .map(textarea => textarea.value.trim())
            .filter(text => text.length > 0);

        if (inputs.length === 0) {
            this.showToast('Please enter at least one opportunity', 'warning');
            this.hideLoading();
            return;
        }

        try {
            const results = await Promise.all(inputs.map((input, index) => 
                this.processIndividualOpportunity(input, index + 1)
            ));

            this.opportunities = [...this.opportunities, ...results];
            this.saveToStorage();
            this.updateStats();
            this.renderDashboard();
            this.showResults(results);
            this.showToast(`Successfully processed ${results.length} opportunities`, 'success');
            
        } catch (error) {
            console.error('Processing error:', error);
            this.showToast('Error processing opportunities', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async processIndividualOpportunity(input, index) {
        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
        
        // Mock opportunity analysis
        const opportunity = this.parseOpportunityData(input, index);
        const analysis = this.performEightPointAnalysis(opportunity);
        
        return {
            id: `OPP-${Date.now()}-${index}`,
            ...opportunity,
            analysis,
            processedAt: new Date(),
            confidence: this.calculateConfidenceScore(opportunity)
        };
    }

    parseOpportunityData(input, index) {
        // Enhanced parsing logic
        const isURL = input.startsWith('http');
        
        // Mock data extraction
        const titles = [
            'Aircraft Engine Parts Supply',
            'F-16 Avionics Components',
            'C-130 Hydraulic Systems',
            'Boeing 737 Landing Gear',
            'Military Communication Equipment',
            'Aerospace Fasteners',
            'Navigation System Components',
            'Aircraft Electrical Harnesses'
        ];

        const naicsCodes = ['336411', '336412', '336413', '488190', '332912', '334511'];
        const cos = ['John Smith', 'Sarah Johnson', 'Mike Wilson', 'Lisa Brown', 'David Lee'];
        const partNumbers = [
            ['MS20426AD4-6', 'NAS1351N4-16', 'AN960-416'],
            ['5998-01-234-5678', 'NSN-123-456-7890'],
            ['PWA-54321', 'HAM-98765'],
            ['BOEING-123ABC', 'SPIRIT-456DEF']
        ];

        const randomNaics = naicsCodes[Math.floor(Math.random() * naicsCodes.length)];
        const isAerospace = ['336411', '336412', '336413', '488190'].includes(randomNaics);
        
        return {
            title: titles[index % titles.length],
            url: isURL ? input : null,
            text: isURL ? null : input,
            naicsCode: randomNaics,
            naicsDescription: this.getNaicsDescription(randomNaics),
            isAerospace,
            contractingOfficer: cos[Math.floor(Math.random() * cos.length)],
            dueDate: new Date(Date.now() + Math.random() * 30 * 24 * 60 * 60 * 1000),
            partNumbers: partNumbers[Math.floor(Math.random() * partNumbers.length)],
            setAside: Math.random() > 0.5 ? 'Small Business' : null,
            estimatedValue: Math.floor(Math.random() * 5000000) + 50000
        };
    }

    performEightPointAnalysis(opportunity) {
        const checklist = [
            {
                point: 'Commercial Item Analysis',
                description: 'Is this a commercial off-the-shelf item?',
                status: this.determineCommercialStatus(opportunity),
                recommendation: this.getCommercialRecommendation(opportunity)
            },
            {
                point: 'Technical Data Package (TDP)',
                description: 'Is technical data available for manufacturing?',
                status: Math.random() > 0.3 ? 'go' : 'analysis',
                recommendation: 'Request TDP access from government'
            },
            {
                point: 'Certification Requirements',
                description: 'What certifications are required?',
                status: opportunity.isAerospace ? 'go' : 'analysis',
                recommendation: opportunity.isAerospace ? 'FAA certifications available' : 'Verify requirements'
            },
            {
                point: 'Competition Analysis',
                description: 'Level of competition expected',
                status: Math.random() > 0.4 ? 'go' : 'analysis',
                recommendation: 'Moderate competition expected'
            },
            {
                point: 'Manufacturing Capability',
                description: 'Do we have manufacturing capability?',
                status: opportunity.isAerospace ? 'go' : 'nogo',
                recommendation: opportunity.isAerospace ? 'Strong aerospace manufacturing base' : 'Outside core competency'
            },
            {
                point: 'Quality System Compliance',
                description: 'Quality system alignment with requirements',
                status: 'go',
                recommendation: 'AS9120B certification covers requirements'
            },
            {
                point: 'Supply Chain Assessment',
                description: 'Supplier network availability',
                status: Math.random() > 0.2 ? 'go' : 'analysis',
                recommendation: 'Established supplier relationships'
            },
            {
                point: 'Financial Viability',
                description: 'Profit potential and resource requirements',
                status: opportunity.estimatedValue > 100000 ? 'go' : 'analysis',
                recommendation: `Est. value: $${opportunity.estimatedValue.toLocaleString()}`
            }
        ];

        const goCount = checklist.filter(item => item.status === 'go').length;
        const nogoCount = checklist.filter(item => item.status === 'nogo').length;
        
        let overallStatus;
        if (nogoCount > 2) overallStatus = 'nogo';
        else if (goCount >= 6) overallStatus = 'go';
        else overallStatus = 'analysis';

        return {
            checklist,
            overallStatus,
            goCount,
            nogoCount,
            keyBlockers: checklist.filter(item => item.status === 'nogo').map(item => item.point)
        };
    }

    determineCommercialStatus(opportunity) {
        if (opportunity.isAerospace && opportunity.partNumbers.length > 0) {
            return Math.random() > 0.3 ? 'go' : 'analysis';
        }
        return Math.random() > 0.5 ? 'go' : 'nogo';
    }

    getCommercialRecommendation(opportunity) {
        if (opportunity.isAerospace) {
            return 'FAA-certified commercial channels available';
        }
        return 'Verify commercial item classification';
    }

    calculateConfidenceScore(opportunity) {
        let score = 0;
        if (opportunity.title) score += 20;
        if (opportunity.naicsCode) score += 20;
        if (opportunity.contractingOfficer) score += 20;
        if (opportunity.partNumbers && opportunity.partNumbers.length > 0) score += 20;
        if (opportunity.dueDate) score += 20;

        if (score >= 80) return 'high';
        if (score >= 60) return 'medium';
        return 'low';
    }

    // Dashboard Rendering
    renderDashboard() {
        const tbody = document.getElementById('opportunitiesTableBody');
        const emptyState = document.getElementById('emptyState');

        if (!tbody || !emptyState) return;

        if (this.opportunities.length === 0) {
            tbody.style.display = 'none';
            emptyState.style.display = 'block';
            return;
        }

        tbody.style.display = '';
        emptyState.style.display = 'none';

        const filtered = this.getFilteredOpportunities();
        tbody.innerHTML = filtered.map(opp => `
            <tr onclick="app.showOpportunityDetails('${opp.id}')" style="cursor: pointer;">
                <td>
                    <div class="opp-id">
                        ${opp.id}
                        ${opp.isAerospace ? '<span class="aerospace-badge">✈️ Aerospace</span>' : ''}
                    </div>
                </td>
                <td>
                    <div class="opp-title" title="${opp.title}">
                        ${this.truncateText(opp.title, 40)}
                    </div>
                </td>
                <td>
                    <span class="status-indicator status-${opp.analysis.overallStatus}">
                        ${this.getStatusIcon(opp.analysis.overallStatus)} ${this.getStatusText(opp.analysis.overallStatus)}
                    </span>
                </td>
                <td>
                    <div class="key-blockers">
                        ${opp.analysis.keyBlockers.slice(0, 2).join(', ')}
                        ${opp.analysis.keyBlockers.length > 2 ? '...' : ''}
                    </div>
                </td>
                <td>
                    <div class="part-numbers">
                        ${(opp.partNumbers || []).slice(0, 2).join(', ')}
                        ${(opp.partNumbers || []).length > 2 ? '...' : ''}
                    </div>
                </td>
                <td>${opp.contractingOfficer || 'N/A'}</td>
                <td>
                    <div class="${this.isDueSoon(opp.dueDate) ? 'due-soon' : ''}">
                        ${this.formatDate(opp.dueDate)}
                    </div>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn copy" onclick="event.stopPropagation(); app.copyReport('${opp.id}')" title="Copy Report">
                            📋
                        </button>
                        <button class="action-btn email" onclick="event.stopPropagation(); app.emailCO('${opp.id}')" title="Email CO">
                            📧
                        </button>
                        <button class="action-btn save" onclick="event.stopPropagation(); app.saveForLater('${opp.id}')" title="Save for Later">
                            📌
                        </button>
                        <button class="action-btn view" onclick="event.stopPropagation(); app.showOpportunityDetails('${opp.id}')" title="View Details">
                            🔍
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getFilteredOpportunities() {
        let filtered = [...this.opportunities];
        
        const searchInput = document.getElementById('searchInput');
        const statusFilter = document.getElementById('statusFilter');
        const naicsFilter = document.getElementById('naicsFilter');
        
        const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
        const statusValue = statusFilter ? statusFilter.value : '';
        const naicsValue = naicsFilter ? naicsFilter.value : '';

        if (searchTerm) {
            filtered = filtered.filter(opp => 
                opp.title.toLowerCase().includes(searchTerm) ||
                opp.id.toLowerCase().includes(searchTerm) ||
                (opp.contractingOfficer && opp.contractingOfficer.toLowerCase().includes(searchTerm)) ||
                (opp.partNumbers && opp.partNumbers.some(pn => pn.toLowerCase().includes(searchTerm)))
            );
        }

        if (statusValue) {
            filtered = filtered.filter(opp => opp.analysis.overallStatus === statusValue);
        }

        if (naicsValue === 'aerospace') {
            filtered = filtered.filter(opp => opp.isAerospace);
        }

        this.filteredOpportunities = filtered;
        return filtered;
    }

    // Statistics Update
    updateStats() {
        const total = this.opportunities.length;
        const goCount = this.opportunities.filter(opp => opp.analysis.overallStatus === 'go').length;
        const analysisCount = this.opportunities.filter(opp => opp.analysis.overallStatus === 'analysis').length;
        const nogoCount = this.opportunities.filter(opp => opp.analysis.overallStatus === 'nogo').length;
        
        const dueThisWeek = this.opportunities.filter(opp => {
            const dueDate = new Date(opp.dueDate);
            const today = new Date();
            const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
            return dueDate >= today && dueDate <= nextWeek;
        }).length;

        const totalElement = document.getElementById('totalOpps');
        const goElement = document.getElementById('goCount');
        const analysisElement = document.getElementById('analysisCount');
        const nogoElement = document.getElementById('nogoCount');
        const dueElement = document.getElementById('dueThisWeek');

        if (totalElement) totalElement.textContent = total;
        if (goElement) goElement.textContent = goCount;
        if (analysisElement) analysisElement.textContent = analysisCount;
        if (nogoElement) nogoElement.textContent = nogoCount;
        if (dueElement) dueElement.textContent = dueThisWeek;
    }

    // Analytics Rendering
    renderAnalytics() {
        if (this.opportunities.length === 0) {
            // Show empty state for analytics
            return;
        }
        
        setTimeout(() => {
            this.renderStatusChart();
            this.renderNaicsChart();
            this.renderTimelineChart();
            this.renderBlockersChart();
        }, 100);
    }

    renderStatusChart() {
        const canvas = document.getElementById('statusChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        
        const data = {
            labels: ['Go', 'Further Analysis', 'No-Go'],
            datasets: [{
                data: [
                    this.opportunities.filter(opp => opp.analysis.overallStatus === 'go').length,
                    this.opportunities.filter(opp => opp.analysis.overallStatus === 'analysis').length,
                    this.opportunities.filter(opp => opp.analysis.overallStatus === 'nogo').length
                ],
                backgroundColor: ['#22C55E', '#F59E0B', '#EF4444']
            }]
        };

        if (this.charts.status) {
            this.charts.status.destroy();
        }

        this.charts.status = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    renderNaicsChart() {
        const canvas = document.getElementById('naicsChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        const naicsData = {};
        this.opportunities.forEach(opp => {
            const naics = opp.naicsDescription || 'Unknown';
            naicsData[naics] = (naicsData[naics] || 0) + 1;
        });

        const data = {
            labels: Object.keys(naicsData),
            datasets: [{
                data: Object.values(naicsData),
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545']
            }]
        };

        if (this.charts.naics) {
            this.charts.naics.destroy();
        }

        this.charts.naics = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    renderTimelineChart() {
        const container = document.getElementById('timelineChart');
        if (!container) return;

        const sortedOpps = [...this.opportunities].sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
        
        container.innerHTML = sortedOpps.map(opp => `
            <div class="timeline-item">
                <div class="timeline-date">${this.formatDate(opp.dueDate)}</div>
                <div class="timeline-title">${this.truncateText(opp.title, 30)}</div>
                <div class="timeline-status status-${opp.analysis.overallStatus}">
                    ${this.getStatusIcon(opp.analysis.overallStatus)}
                </div>
            </div>
        `).join('');
    }

    renderBlockersChart() {
        const canvas = document.getElementById('blockersChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        const blockerCounts = {};
        this.opportunities.forEach(opp => {
            opp.analysis.keyBlockers.forEach(blocker => {
                blockerCounts[blocker] = (blockerCounts[blocker] || 0) + 1;
            });
        });

        const data = {
            labels: Object.keys(blockerCounts),
            datasets: [{
                label: 'Frequency',
                data: Object.values(blockerCounts),
                backgroundColor: '#EF4444'
            }]
        };

        if (this.charts.blockers) {
            this.charts.blockers.destroy();
        }

        this.charts.blockers = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Export Functionality - Fixed
    toggleExportMenu() {
        const menu = document.getElementById('exportMenu');
        if (menu) {
            menu.classList.toggle('show');
        }
    }

    exportData(format) {
        const data = this.getFilteredOpportunities();
        
        switch(format) {
            case 'jsonl':
                this.exportAsJSONL(data);
                break;
            case 'csv':
                this.exportAsCSV(data);
                break;
            case 'pipeline':
                this.exportAsPipeline(data);
                break;
            case 'summary':
                this.exportAsSummary(data);
                break;
        }

        this.toggleExportMenu();
        this.showToast(`Exported ${data.length} opportunities as ${format.toUpperCase()}`, 'success');
    }

    exportAsJSONL(data) {
        const jsonl = data.map(opp => JSON.stringify(opp)).join('\n');
        this.downloadFile(jsonl, 'opportunities.jsonl', 'application/jsonl');
    }

    exportAsCSV(data) {
        const headers = ['ID', 'Title', 'Status', 'NAICS', 'CO', 'Due Date', 'Part Numbers', 'Blockers'];
        const rows = data.map(opp => [
            opp.id,
            opp.title,
            opp.analysis.overallStatus,
            opp.naicsDescription,
            opp.contractingOfficer,
            this.formatDate(opp.dueDate),
            (opp.partNumbers || []).join('; '),
            opp.analysis.keyBlockers.join('; ')
        ]);

        const csv = [headers, ...rows].map(row => 
            row.map(cell => `"${cell}"`).join(',')
        ).join('\n');

        this.downloadFile(csv, 'opportunities.csv', 'text/csv');
    }

    exportAsPipeline(data) {
        const pipeline = data.map(opp => 
            `${opp.id}|${opp.title}|${opp.analysis.overallStatus}|${opp.contractingOfficer}|${this.formatDate(opp.dueDate)}`
        ).join('\n');

        this.downloadFile(pipeline, 'opportunities_pipeline.txt', 'text/plain');
    }

    exportAsSummary(data) {
        const html = this.generateSummaryHTML(data);
        this.downloadFile(html, 'executive_summary.html', 'text/html');
    }

    downloadFile(content, filename, contentType) {
        const blob = new Blob([content], { type: contentType });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // Modal Management - Fixed
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.remove('show');
        });
    }

    showOpportunityDetails(oppId) {
        const opp = this.opportunities.find(o => o.id === oppId);
        if (!opp) return;

        const modalBody = document.getElementById('modalBody');
        if (modalBody) {
            modalBody.innerHTML = this.generateOpportunityDetailsHTML(opp);
        }
        
        const modalTitle = document.getElementById('modalTitle');
        if (modalTitle) {
            modalTitle.textContent = opp.title;
        }
        
        this.showModal('detailModal');
    }

    generateOpportunityDetailsHTML(opp) {
        return `
            <div class="opportunity-details">
                <div class="detail-section">
                    <h4>Basic Information</h4>
                    <div class="detail-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                        <div><strong>ID:</strong> ${opp.id}</div>
                        <div><strong>Status:</strong> 
                            <span class="status-indicator status-${opp.analysis.overallStatus}">
                                ${this.getStatusIcon(opp.analysis.overallStatus)} ${this.getStatusText(opp.analysis.overallStatus)}
                            </span>
                        </div>
                        <div><strong>NAICS:</strong> ${opp.naicsCode} - ${opp.naicsDescription}</div>
                        <div><strong>Contracting Officer:</strong> ${opp.contractingOfficer}</div>
                        <div><strong>Due Date:</strong> ${this.formatDate(opp.dueDate)}</div>
                        <div><strong>Estimated Value:</strong> $${opp.estimatedValue.toLocaleString()}</div>
                        <div><strong>Confidence:</strong> 
                            <span class="confidence-badge" data-level="${opp.confidence}">
                                ${this.getConfidenceIcon(opp.confidence)} ${opp.confidence.toUpperCase()}
                            </span>
                        </div>
                    </div>
                </div>

                <div class="detail-section" style="margin-bottom: 20px;">
                    <h4>Part Numbers</h4>
                    <div class="part-numbers-list">
                        ${(opp.partNumbers || []).map(pn => `<span class="part-number" style="background: var(--color-secondary); padding: 4px 8px; border-radius: 4px; margin-right: 8px; font-family: monospace;">${pn}</span>`).join('')}
                    </div>
                </div>

                <div class="detail-section">
                    <h4>8-Point Analysis</h4>
                    <div class="checklist-results">
                        ${opp.analysis.checklist.map(item => `
                            <div class="checklist-item ${item.status}" style="margin-bottom: 12px;">
                                <div style="display: flex; align-items: flex-start; gap: 12px;">
                                    <div class="checklist-icon" style="font-size: 18px;">${this.getStatusIcon(item.status)}</div>
                                    <div class="checklist-content">
                                        <div class="checklist-point" style="font-weight: 600; margin-bottom: 4px;">${item.point}</div>
                                        <div class="checklist-description" style="color: var(--color-text-secondary); margin-bottom: 4px;">${item.description}</div>
                                        <div class="checklist-recommendation" style="font-style: italic;">${item.recommendation}</div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                ${opp.analysis.overallStatus === 'analysis' ? `
                    <div class="detail-section">
                        <h4>Recommended Actions</h4>
                        <div class="recommendations">
                            ${this.generateRecommendations(opp).map(rec => `
                                <div class="recommendation-item" style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px; padding: 8px; background: var(--color-bg-1); border-radius: 6px;">
                                    <i class="fas fa-lightbulb" style="color: var(--sos-warning);"></i>
                                    ${rec}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    // Action Handlers
    copyReport(oppId) {
        const opp = this.opportunities.find(o => o.id === oppId);
        if (!opp) return;

        const report = this.generateTextReport(opp);
        if (navigator.clipboard) {
            navigator.clipboard.writeText(report).then(() => {
                this.showToast('Report copied to clipboard', 'success');
            }).catch(() => {
                this.showToast('Failed to copy report', 'error');
            });
        } else {
            this.showToast('Clipboard not available', 'warning');
        }
    }

    emailCO(oppId) {
        const opp = this.opportunities.find(o => o.id === oppId);
        if (!opp) return;

        const template = this.getEmailTemplate(opp);
        const mailto = `mailto:${opp.contractingOfficer.toLowerCase().replace(' ', '.')}@example.gov?subject=${encodeURIComponent(template.subject)}&body=${encodeURIComponent(template.body)}`;
        window.open(mailto, '_blank');
    }

    saveForLater(oppId) {
        const opp = this.opportunities.find(o => o.id === oppId);
        if (!opp) return;

        opp.saved = true;
        this.saveToStorage();
        this.showToast('Opportunity saved for later', 'success');
    }

    // Utility Functions
    getStatusIcon(status) {
        const icons = {
            go: '🟢',
            analysis: '🟡',
            nogo: '🔴'
        };
        return icons[status] || '⚪';
    }

    getStatusText(status) {
        const texts = {
            go: 'GO',
            analysis: 'FURTHER ANALYSIS',
            nogo: 'NO-GO'
        };
        return texts[status] || 'UNKNOWN';
    }

    getConfidenceIcon(level) {
        const icons = {
            high: '✅',
            medium: '⚠️',
            low: '❓'
        };
        return icons[level] || '❓';
    }

    truncateText(text, length) {
        return text.length > length ? text.substring(0, length) + '...' : text;
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString();
    }

    isDueSoon(date) {
        const dueDate = new Date(date);
        const today = new Date();
        const timeDiff = dueDate.getTime() - today.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
        return daysDiff <= 30 && daysDiff >= 0;
    }

    getNaicsDescription(code) {
        const descriptions = {
            '336411': 'Aircraft Manufacturing',
            '336412': 'Aircraft Engine and Engine Parts',
            '336413': 'Other Aircraft Parts and Auxiliary Equipment',
            '488190': 'Other Support Activities for Air Transportation',
            '332912': 'Fluid Power Valve and Hose Fitting Manufacturing',
            '334511': 'Search, Detection, Navigation, Guidance, Aeronautical Systems'
        };
        return descriptions[code] || 'Other Manufacturing';
    }

    // Storage Management
    saveToStorage() {
        try {
            localStorage.setItem('sos_opportunities', JSON.stringify(this.opportunities));
            this.saveToHistory();
        } catch (error) {
            console.error('Error saving to storage:', error);
        }
    }

    loadFromStorage() {
        try {
            const stored = localStorage.getItem('sos_opportunities');
            if (stored) {
                this.opportunities = JSON.parse(stored);
            }
        } catch (error) {
            console.error('Error loading from storage:', error);
            this.opportunities = [];
        }
    }

    saveToHistory() {
        try {
            const history = JSON.parse(localStorage.getItem('sos_history') || '[]');
            const newEntry = {
                id: Date.now(),
                date: new Date(),
                count: this.opportunities.length,
                summary: this.getHistorySummary()
            };
            
            history.unshift(newEntry);
            if (history.length > 10) history.pop();
            
            localStorage.setItem('sos_history', JSON.stringify(history));
        } catch (error) {
            console.error('Error saving history:', error);
        }
    }

    // Loading and Toast Management
    showLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('show');
        }
    }

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('show');
        }
    }

    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div class="toast-content" style="display: flex; justify-content: space-between; align-items: center;">
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; cursor: pointer; font-size: 16px; margin-left: 12px;">×</button>
            </div>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 5000);
    }

    // Additional helper methods
    clearAll() {
        document.querySelectorAll('.copy-box textarea').forEach(textarea => {
            textarea.value = '';
        });
        const resultsSection = document.getElementById('resultsSection');
        if (resultsSection) {
            resultsSection.style.display = 'none';
        }
        this.showToast('All inputs cleared', 'info');
    }

    focusFirstEmptyTextarea() {
        const textareas = document.querySelectorAll('.copy-box textarea');
        const firstEmpty = Array.from(textareas).find(textarea => !textarea.value.trim());
        if (firstEmpty) {
            firstEmpty.focus();
        }
    }

    filterOpportunities() {
        this.renderDashboard();
    }

    navigateOpportunities(direction) {
        const rows = document.querySelectorAll('#opportunitiesTableBody tr');
        if (rows.length === 0) return;

        this.currentSelectedIndex += direction;
        if (this.currentSelectedIndex < 0) this.currentSelectedIndex = rows.length - 1;
        if (this.currentSelectedIndex >= rows.length) this.currentSelectedIndex = 0;

        rows.forEach(row => row.classList.remove('selected'));
        if (rows[this.currentSelectedIndex]) {
            rows[this.currentSelectedIndex].classList.add('selected');
        }
    }

    toggleOpportunityDetails() {
        const rows = document.querySelectorAll('#opportunitiesTableBody tr');
        if (rows[this.currentSelectedIndex]) {
            rows[this.currentSelectedIndex].click();
        }
    }

    toggleTheme() {
        const currentTheme = document.documentElement.dataset.colorScheme || 'light';
        document.documentElement.dataset.colorScheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        const themeIcon = document.querySelector('#themeToggle i');
        if (themeIcon) {
            themeIcon.className = currentTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    handlePDFUpload(files) {
        const preview = document.getElementById('pdfPreview');
        if (!preview) return;

        Array.from(files).forEach(file => {
            this.showToast(`Processing PDF: ${file.name}`, 'info');
            
            const fileDiv = document.createElement('div');
            fileDiv.className = 'pdf-file';
            fileDiv.innerHTML = `
                <i class="fas fa-file-pdf" style="color: #dc2626;"></i>
                <span>${file.name}</span>
                <span style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">(${(file.size / 1024).toFixed(1)} KB)</span>
            `;
            preview.appendChild(fileDiv);
            
            setTimeout(() => {
                this.showToast(`PDF processed: ${file.name}`, 'success');
            }, 2000);
        });
    }

    showResults(results) {
        const resultsSection = document.getElementById('resultsSection');
        const container = document.getElementById('resultsContainer');
        
        if (!resultsSection || !container) return;
        
        container.innerHTML = results.map(opp => `
            <div class="opportunity-result">
                <div class="result-header" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'block' : 'none'">
                    <div class="result-title">${opp.title}</div>
                    <div class="status-indicator status-${opp.analysis.overallStatus}">
                        ${this.getStatusIcon(opp.analysis.overallStatus)} ${this.getStatusText(opp.analysis.overallStatus)}
                    </div>
                </div>
                <div class="result-body" style="display: none;">
                    ${this.generateOpportunityDetailsHTML(opp)}
                </div>
            </div>
        `).join('');
        
        resultsSection.style.display = 'block';
        this.switchTab('processor');
    }

    generateRecommendations(opp) {
        const recommendations = [];
        
        if (opp.analysis.keyBlockers.includes('Commercial Item Analysis')) {
            recommendations.push('Contact CO about commercial exemption process');
        }
        if (opp.analysis.keyBlockers.includes('Technical Data Package (TDP)')) {
            recommendations.push('Request TDP access through FOIA if necessary');
        }
        if (opp.analysis.keyBlockers.includes('Certification Requirements')) {
            recommendations.push('Verify certification requirements with quality team');
        }
        
        return recommendations.length > 0 ? recommendations : ['No specific recommendations at this time'];
    }

    generateTextReport(opp) {
        return `
SOS OPPORTUNITY ANALYSIS REPORT
================================

Opportunity: ${opp.title}
ID: ${opp.id}
Status: ${this.getStatusText(opp.analysis.overallStatus)}
Due Date: ${this.formatDate(opp.dueDate)}
Contracting Officer: ${opp.contractingOfficer}

8-POINT ANALYSIS:
${opp.analysis.checklist.map(item => 
    `${this.getStatusIcon(item.status)} ${item.point}: ${item.recommendation}`
).join('\n')}

KEY BLOCKERS:
${opp.analysis.keyBlockers.length > 0 ? opp.analysis.keyBlockers.map(b => `- ${b}`).join('\n') : 'None'}

CONFIDENCE LEVEL: ${opp.confidence.toUpperCase()}

Generated by SOS Opportunity Processor
        `.trim();
    }

    getEmailTemplate(opp) {
        if (opp.analysis.keyBlockers.includes('Commercial Item Analysis')) {
            return {
                subject: `Clarification Request - ${opp.id} Commercial Supply Capability`,
                body: `Dear ${opp.contractingOfficer},

We are reviewing solicitation ${opp.id} and would like to clarify the commercial supply provisions. Source One Spares maintains FAA certifications (8130-3, AC 00-56) and can provide full traceability documentation for commercial aircraft parts.

Would it be possible to discuss accepting FAA-certified commercial channels for this requirement?

Best regards,
Source One Spares Team
CAGE: 95QA6`
            };
        }
        
        return {
            subject: `Technical Data Package Access Request - ${opp.id}`,
            body: `Dear ${opp.contractingOfficer},

Regarding solicitation ${opp.id}, we would like to request access to the technical data package to properly assess our capabilities for this requirement.

Source One Spares (CAGE: 95QA6) has extensive experience with aerospace components and maintains all required quality certifications.

Thank you for your consideration.

Best regards,
Source One Spares Team`
        };
    }

    getHistorySummary() {
        const goCount = this.opportunities.filter(opp => opp.analysis.overallStatus === 'go').length;
        const analysisCount = this.opportunities.filter(opp => opp.analysis.overallStatus === 'analysis').length;
        const nogoCount = this.opportunities.filter(opp => opp.analysis.overallStatus === 'nogo').length;
        
        return { goCount, analysisCount, nogoCount };
    }

    renderHistory() {
        const container = document.getElementById('historyContainer');
        if (!container) return;

        try {
            const history = JSON.parse(localStorage.getItem('sos_history') || '[]');
            
            if (history.length === 0) {
                container.innerHTML = '<div class="empty-state"><p>No previous analyses found.</p></div>';
                return;
            }
            
            container.innerHTML = history.map(entry => `
                <div class="history-item" onclick="app.loadHistoryEntry(${entry.id})">
                    <div class="history-header-info">
                        <div class="history-title">Analysis Session</div>
                        <div class="history-date">${new Date(entry.date).toLocaleDateString()}</div>
                    </div>
                    <div class="history-stats">
                        <span>Total: ${entry.count}</span>
                        <span>Go: ${entry.summary.goCount}</span>
                        <span>Analysis: ${entry.summary.analysisCount}</span>
                        <span>No-Go: ${entry.summary.nogoCount}</span>
                    </div>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error rendering history:', error);
            container.innerHTML = '<div class="empty-state"><p>Error loading history.</p></div>';
        }
    }

    clearHistory() {
        try {
            localStorage.removeItem('sos_history');
            this.renderHistory();
            this.showToast('History cleared', 'success');
        } catch (error) {
            console.error('Error clearing history:', error);
            this.showToast('Error clearing history', 'error');
        }
    }

    loadHistoryEntry(entryId) {
        this.showToast('History entry loaded', 'info');
    }

    saveResults() {
        if (this.opportunities.length === 0) {
            this.showToast('No results to save', 'warning');
            return;
        }

        this.saveToStorage();
        this.showToast('Results saved successfully', 'success');
    }

    generateSummaryHTML(data) {
        const goCount = data.filter(opp => opp.analysis.overallStatus === 'go').length;
        const analysisCount = data.filter(opp => opp.analysis.overallStatus === 'analysis').length;
        const nogoCount = data.filter(opp => opp.analysis.overallStatus === 'nogo').length;
        
        return `
<!DOCTYPE html>
<html>
<head>
    <title>SOS Executive Summary</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { color: #0057B7; border-bottom: 2px solid #0057B7; padding-bottom: 10px; }
        .stats { display: flex; gap: 20px; margin: 20px 0; }
        .stat { background: #f5f5f5; padding: 15px; border-radius: 8px; text-align: center; }
        .opportunities { margin-top: 20px; }
        .opp-item { margin: 10px 0; padding: 10px; border-left: 4px solid #ccc; }
        .go { border-left-color: #22C55E; }
        .analysis { border-left-color: #F59E0B; }
        .nogo { border-left-color: #EF4444; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Source One Spares - Executive Summary</h1>
        <p>Generated on ${new Date().toLocaleDateString()}</p>
    </div>
    
    <div class="stats">
        <div class="stat">
            <h3>${data.length}</h3>
            <p>Total Opportunities</p>
        </div>
        <div class="stat">
            <h3>${goCount}</h3>
            <p>Go Opportunities</p>
        </div>
        <div class="stat">
            <h3>${analysisCount}</h3>
            <p>Further Analysis</p>
        </div>
        <div class="stat">
            <h3>${nogoCount}</h3>
            <p>No-Go</p>
        </div>
    </div>
    
    <div class="opportunities">
        <h2>Opportunity Details</h2>
        ${data.map(opp => `
            <div class="opp-item ${opp.analysis.overallStatus}">
                <h3>${opp.title}</h3>
                <p><strong>Status:</strong> ${this.getStatusText(opp.analysis.overallStatus)}</p>
                <p><strong>Due Date:</strong> ${this.formatDate(opp.dueDate)}</p>
                <p><strong>CO:</strong> ${opp.contractingOfficer}</p>
                ${opp.analysis.keyBlockers.length > 0 ? 
                    `<p><strong>Key Blockers:</strong> ${opp.analysis.keyBlockers.join(', ')}</p>` : ''
                }
            </div>
        `).join('')}
    </div>
</body>
</html>
        `;
    }
}

// Initialize the application when DOM is ready
let app;

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        app = new SOSProcessor();
    });
} else {
    app = new SOSProcessor();
}